package com.newcrud.Newcrud;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NewcrudApplication {

	public static void main(String[] args) {
		SpringApplication.run(NewcrudApplication.class, args);
	}

}
